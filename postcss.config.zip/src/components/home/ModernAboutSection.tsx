import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, ArrowUpRight, CheckCircle } from 'lucide-react';
import { motion } from 'framer-motion';
import { Button } from '../ui/button';

const ModernAboutSection = () => {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.2 }
    }
  };

  const itemVariants = {
    hidden: { y: 30, opacity: 0 },
    visible: { 
      y: 0, 
      opacity: 1,
      transition: { duration: 0.6, ease: [0.22, 1, 0.36, 1] }
    }
  };

  return (
    <section id="about-section" className="py-20 relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-1/2 -left-64 w-96 h-96 bg-milgen-yellow/10 rounded-full blur-3xl"></div>
        <div className="absolute -bottom-64 -right-64 w-[40rem] h-[40rem] bg-milgen-yellow/5 rounded-full blur-3xl"></div>
      </div>
      
      <div className="container-custom relative z-10">
        <motion.div 
          className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center"
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
        >
          {/* Image with animated decoration */}
          <motion.div 
            className="relative"
            variants={itemVariants}
          >
            <div className="absolute -top-4 -left-4 w-24 h-24 bg-milgen-yellow/20 rounded-full blur-xl"></div>
            <div className="relative z-10 rounded-2xl overflow-hidden shadow-2xl">
              <img 
                src="https://images.unsplash.com/photo-1482938289607-e9573fc25ebb?q=80&w=1920" 
                alt="Mining operations" 
                className="w-full h-full object-cover"
              />
              {/* Overlay gradient */}
              <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent opacity-60"></div>
            </div>
            
            {/* Floating accent element */}
            <motion.div 
              className="absolute -bottom-6 -right-6 bg-white p-4 rounded-xl shadow-xl flex items-center space-x-3"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.6, duration: 0.5 }}
            >
              <div className="w-10 h-10 rounded-full bg-milgen-yellow/20 flex items-center justify-center">
                <CheckCircle className="text-milgen-yellow" size={24} />
              </div>
              <div>
                <p className="text-sm font-medium">Sustainable Mining</p>
                <p className="text-xs text-gray-500">ISO Certified</p>
              </div>
            </motion.div>
          </motion.div>
          
          {/* Content */}
          <motion.div 
            className="space-y-8"
            variants={itemVariants}
          >
            <motion.div 
              className="inline-block"
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
            >
              <span className="px-4 py-1.5 bg-milgen-yellow/10 text-milgen-yellow rounded-full text-sm font-medium">
                About Us
              </span>
            </motion.div>
            
            <motion.h2 
              className="text-4xl md:text-5xl font-bold tracking-tight"
              variants={itemVariants}
            >
              <span className="text-milgen-yellow">Who</span> We Are
            </motion.h2>
            
            <motion.div 
              className="space-y-4 text-lg text-gray-600"
              variants={itemVariants}
            >
              <p>
                Milgen Mines leads in responsible mining and global exports. Our practices prioritize sustainability, innovation, and community development across Africa.
              </p>
              
              <p>
                We harness Africa's vast mineral wealth to support economic growth, industrial development, job creation, and foreign investment through sustainable extraction and technological innovation.
              </p>
            </motion.div>
            
            <motion.div 
              className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-4"
              variants={containerVariants}
            >
              <motion.div 
                className="bg-white/50 backdrop-blur-sm p-6 rounded-2xl shadow-sm border border-gray-100"
                variants={itemVariants}
                whileHover={{ y: -5, transition: { duration: 0.2 } }}
              >
                <div className="w-12 h-12 rounded-full bg-milgen-yellow/20 flex items-center justify-center mb-4">
                  <CheckCircle className="text-milgen-yellow" size={24} />
                </div>
                <h3 className="font-bold text-xl mb-2">Sustainable Resource</h3>
                <p className="text-gray-600">Ethical mining, conservation, and land rehabilitation</p>
              </motion.div>
              
              <motion.div 
                className="bg-white/50 backdrop-blur-sm p-6 rounded-2xl shadow-sm border border-gray-100"
                variants={itemVariants}
                whileHover={{ y: -5, transition: { duration: 0.2 } }}
              >
                <div className="w-12 h-12 rounded-full bg-milgen-yellow/20 flex items-center justify-center mb-4">
                  <CheckCircle className="text-milgen-yellow" size={24} />
                </div>
                <h3 className="font-bold text-xl mb-2">Economic Growth</h3>
                <p className="text-gray-600">Employment, infrastructure, education support</p>
              </motion.div>
            </motion.div>
            
            <motion.div 
              className="pt-4"
              variants={itemVariants}
            >
              <Button variant="apple" size="apple-lg" asChild>
                <Link to="/about" className="flex items-center">
                  Learn more about us
                  <ArrowUpRight className="ml-2" size={18} />
                </Link>
              </Button>
            </motion.div>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
};

export default ModernAboutSection; 